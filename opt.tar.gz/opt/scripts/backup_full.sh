#!/bin/bash

if [ $1 == "-help" ];
then
	echo ""
	echo "#Sintaxis: ./backup_full.sh dir_origen dir_destino"
	echo "NOTA: Los directorios deben existir."
	echo ""
else

if [ ! -d "$1" ] || [ ! -d "$2" ]; 
then
	echo ""
	echo "VERFICIAR: Algunos de los directorios especificados no existen."
	echo ""
else

echo ""
echo "Directorio ingresado: ${1}"
echo ""

NOMBRE=`echo ${1} | awk -F '/' '{print $NF}'`_bkp_`date +'%Y%m%d'`.tar.gz

echo "Nombre de archivo generado: ${NOMBRE}"
echo ""

echo "Directorio destino: ${2}"
echo ""

cd ${1}
echo "### Estructura de directorios backupeada ###"
echo ""

tar zcvf ${2}/${NOMBRE} *
fi
fi
